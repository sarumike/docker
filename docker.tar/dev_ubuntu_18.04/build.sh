#!/bin/bash

docker build --no-cache -t ubuntu:18.04 .
